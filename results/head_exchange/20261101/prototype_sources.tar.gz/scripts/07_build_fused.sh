#!/usr/bin/env bash
set -euo pipefail
cd /root/autodl-tmp/dsv41-kernel-20261101-105936
/usr/local/cuda/bin/nvcc -O3 -std=c++17 -arch=sm_90a --shared \
  -Xcompiler -fPIC -cudart shared -Xlinker -rpath -Xlinker /usr/local/cuda/lib64 \
  scripts/fused/segment_exchange.cu -o scripts/fused/libsegment_exchange.so
sha256sum scripts/fused/segment_exchange.cu scripts/fused/libsegment_exchange.so
