"""Exact byte-layout, changing-input, graph-replay and lagging-rank tests."""

import argparse
import json
import os
import time
from pathlib import Path

import torch
import torch.distributed as dist
from fused_exchange import FusedExchangeWorkspace


def check_case(rows, iterations, mode, rank):
    q = torch.zeros(rows, 1, 64, 512, device="cuda", dtype=torch.bfloat16)
    sink = torch.arange(64, device="cuda", dtype=torch.float32) + rank * 100
    ws = FusedExchangeWorkspace(q, sink, rank, 2)
    expected_sink = torch.cat(
        [torch.arange(8, device="cuda") + r * 100 for r in range(2)]
    ).float()
    assert torch.equal(ws.sink[:16], expected_sink)
    assert torch.isneginf(ws.sink[16:]).all()
    index = torch.arange(rows * 8 * 512, device="cuda").view(rows, 8, 512)
    local_rows = torch.arange(ws.chunk, device="cuda") + rank * ws.chunk
    h = torch.arange(16, device="cuda")
    d = torch.arange(512, device="cuda")
    row_index = (
        local_rows[:, None, None] * (8 * 512)
        + (h[None, :, None] % 8) * 512
        + d[None, None, :]
    )
    row_index = row_index + 13 * (h[None, :, None] // 8)
    expected_row = torch.zeros_like(ws.row_q)
    checks = torch.empty(iterations, 3, device="cuda", dtype=torch.bool)

    def exchange():
        ws.forward_q(q)
        ws.row_o.copy_(ws.row_q)
        ws.backward_o()

    exchange()
    torch.cuda.synchronize()
    graph = None
    if mode == "graph":
        graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph):
            exchange()
    for step in range(iterations):
        q[:, 0, :8].copy_(
            ((index + 13 * rank + 17 * step) % 251 - 125).to(torch.bfloat16)
        )
        expected_row[:, 0, :16] = ((row_index + 17 * step) % 251 - 125).to(
            torch.bfloat16
        )
        expected_row.masked_fill_(local_rows[:, None, None, None] >= rows, 0)
        if step % 13 == 0 and rank == (step // 13) % 2:
            time.sleep(0.002)
        if graph is None:
            exchange()
        else:
            graph.replay()
        checks[step, 0] = torch.all(ws.row_q == expected_row)
        checks[step, 1] = torch.all(ws.output[:, 0, :8] == q[:, 0, :8])
        checks[step, 2] = torch.all(ws.output[:, 0, 8:] == 0)
    torch.cuda.synchronize()
    passed = checks.cpu().all().item()
    assert passed, {
        "rows": rows,
        "rank": rank,
        "mode": mode,
        "failed": (~checks).nonzero().cpu().tolist(),
    }
    dist.barrier()
    return {
        "rows": rows,
        "mode": mode,
        "iterations": iterations,
        "rank": rank,
        "blocks": ws.blocks,
        "exact": True,
    }


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--rows", type=int, nargs="+", default=[1, 7, 9, 32, 127, 129, 512])
    p.add_argument("--iterations", type=int, default=200)
    p.add_argument("--output", type=Path, required=True)
    args = p.parse_args()
    torch.set_num_threads(1)
    rank = int(os.environ["LOCAL_RANK"])
    torch.cuda.set_device(rank)
    dist.init_process_group("nccl", device_id=torch.device("cuda", rank))
    result = {"status": "running", "ranks": 2, "cases": []}
    try:
        for rows in args.rows:
            for mode in ["eager", "graph"]:
                case = check_case(rows, args.iterations, mode, rank)
                gathered = [None, None]
                dist.all_gather_object(gathered, case)
                if rank == 0:
                    result["cases"].extend(gathered)
                    print(
                        json.dumps(
                            {
                                "rows": rows,
                                "mode": mode,
                                "iterations_per_rank": args.iterations,
                                "exact": True,
                            }
                        ),
                        flush=True,
                    )
                    args.output.write_text(json.dumps(result, indent=2) + "\n")
        result["status"] = "completed"
    except BaseException as exc:
        result["status"] = "failed"
        result["error"] = repr(exc)
        raise
    finally:
        if rank == 0:
            args.output.write_text(json.dumps(result, indent=2) + "\n")
        dist.destroy_process_group()


if __name__ == "__main__":
    main()
