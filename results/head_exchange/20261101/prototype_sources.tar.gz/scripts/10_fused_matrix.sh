#!/usr/bin/env bash
set -euo pipefail
cd /root/autodl-tmp/dsv41-kernel-20261101-105936
export CUDA_VISIBLE_DEVICES=0,1
export OMP_NUM_THREADS=1
export PYTORCH_KERNEL_CACHE_PATH="$PWD/torch-kernel-cache"
timeout 240 .venv/bin/python -m torch.distributed.run --standalone --nproc_per_node=2 \
  scripts/head_exchange_fused_ab.py --rows 1 8 32 64 128 256 512 --context 32768 \
  --repeat 30 --inner 20 --interface flash_mla_interface.py \
  --output results/head_exchange_fused_matrix.json
