"""SM90 peer pushes into final Q/O layouts using PyTorch symmetric allocation.

This prototype owns separate Q/O signal planes. It is serialized per workspace
and stream; concurrent reuse and production vLLM integration are not supported.
"""

import ctypes
import math
import os
from pathlib import Path

import torch
import torch.distributed as dist
import torch.distributed._symmetric_memory as symm
from head_exchange_ab import ExchangeWorkspace


class Plane:
    def __init__(self, data_bytes, blocks, world, rank, device):
        self.flag_offset = (data_bytes + 255) // 256 * 256
        nbytes = self.flag_offset + 128 * blocks
        self.buffer = symm.empty(nbytes, dtype=torch.uint8, device=device)
        self.buffer.zero_()
        self.handle = symm.rendezvous(self.buffer, dist.group.WORLD)
        pointers = self.handle.buffer_ptrs
        assert pointers[rank] == self.buffer.data_ptr()
        self.peer_array = torch.tensor(pointers, dtype=torch.int64, device=device)
        self.data = self.buffer[:data_bytes]


class FusedExchangeWorkspace(ExchangeWorkspace):
    def __init__(self, q, sink, rank, world):
        assert q.is_contiguous() and q.dtype == torch.bfloat16
        assert q.shape[1:] == (1, 64, 512)
        assert torch.cuda.get_device_capability(q.device) == (9, 0)
        assert world in (2, 4, 8)
        self.rows = q.shape[0]
        self.chunk = math.ceil(self.rows / world)
        self.rank, self.world = rank, world
        self.heads, self.active = 8, world * 8
        total_bytes = world * self.chunk * 8 * 512 * 2
        self.blocks = int(
            os.environ.get(
                "HEAD_EXCHANGE_BLOCKS", min(16, max(1, math.ceil(total_bytes / 32768)))
            )
        )
        self.threads = int(os.environ.get("HEAD_EXCHANGE_THREADS", 256))
        assert 1 <= self.blocks <= 32
        row_bytes = 64 * 512 * 2
        self.q_plane = Plane(self.chunk * row_bytes, self.blocks, world, rank, q.device)
        self.o_plane = Plane(
            world * self.chunk * row_bytes, self.blocks, world, rank, q.device
        )
        self.row_q = self.q_plane.data.view(torch.bfloat16).view(self.chunk, 1, 64, 512)
        self.row_o = torch.empty_like(self.row_q)
        self.output = self.o_plane.data.view(torch.bfloat16).view(
            world * self.chunk, 1, 64, 512
        )[: self.rows]
        self.sink = torch.full_like(sink, -torch.inf)
        gathered = torch.empty(self.active, device=q.device, dtype=torch.float32)
        dist.all_gather_single(gathered, sink[:8].contiguous())
        self.sink[: self.active].copy_(gathered)
        self.library = ctypes.CDLL(
            str(Path(__file__).parent / "fused/libsegment_exchange.so")
        )
        self.launch = self.library.launch_segment_exchange
        self.launch.restype = ctypes.c_int
        self.launch.argtypes = [
            ctypes.c_void_p,
            ctypes.c_void_p,
            ctypes.c_uint64,
            ctypes.c_int64,
            ctypes.c_int64,
            ctypes.c_int64,
            ctypes.c_int64,
            *([ctypes.c_int] * 7),
            ctypes.c_void_p,
        ]
        self.stream = torch.cuda.current_stream(q.device).cuda_stream
        self.q_pointer = q.data_ptr()
        torch.cuda.synchronize()
        dist.barrier()

    def _call(
        self,
        src,
        plane,
        src_peer_stride,
        src_row_stride,
        dst_rank_stride,
        dst_row_stride,
        valid_rows,
    ):
        stream = torch.cuda.current_stream().cuda_stream
        rc = self.launch(
            src,
            plane.peer_array.data_ptr(),
            plane.flag_offset,
            src_peer_stride,
            src_row_stride,
            dst_rank_stride,
            dst_row_stride,
            self.chunk,
            valid_rows,
            8 * 512 * 2,
            self.world,
            self.rank,
            self.blocks,
            self.threads,
            stream,
        )
        if rc:
            raise RuntimeError(f"fused head exchange launch failed: CUDA error {rc}")

    def forward_q(self, q):
        assert q.data_ptr() == self.q_pointer, "workspace is bound to its input buffer"
        row = 64 * 512 * 2
        self._call(
            q.data_ptr(),
            self.q_plane,
            self.chunk * row,
            row,
            8 * 512 * 2,
            row,
            self.rows,
        )
        return self.row_q

    def backward_o(self):
        row = 64 * 512 * 2
        self._call(
            self.row_o.data_ptr(),
            self.o_plane,
            8 * 512 * 2,
            row,
            self.chunk * row,
            row,
            self.world * self.chunk,
        )
        return self.output
