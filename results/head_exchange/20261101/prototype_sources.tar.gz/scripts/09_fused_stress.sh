#!/usr/bin/env bash
set -euo pipefail
cd /root/autodl-tmp/dsv41-kernel-20261101-105936
export CUDA_VISIBLE_DEVICES=0,1
export OMP_NUM_THREADS=1
timeout 240 .venv/bin/python -m torch.distributed.run --standalone --nproc_per_node=2 \
  scripts/fused_exchange_stress.py --iterations 200 \
  --output results/fused_exchange_stress.json
