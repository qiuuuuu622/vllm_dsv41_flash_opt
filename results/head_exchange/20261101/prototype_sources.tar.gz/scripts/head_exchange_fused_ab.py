"""A/B the final-layout peer-push transport against the frozen baseline."""

from fused_exchange import FusedExchangeWorkspace
from head_exchange_ab import main

if __name__ == "__main__":
    main(FusedExchangeWorkspace, "symmetric_peer_push")
