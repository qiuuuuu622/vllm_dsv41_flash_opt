#!/usr/bin/env bash
set -euo pipefail
cd /root/autodl-tmp/dsv41-kernel-20261101-105936
export CUDA_VISIBLE_DEVICES=0,1
export OMP_NUM_THREADS=1
# Scope: instrument the exchange kernel's memory accesses. NCCL's kernel-image
# probes and PyTorch's fabric-support probe return handled CUDA API errors in
# this environment; the unfiltered run is preserved in 13-fused-memcheck.log.
# This pass disables API-error reporting, NOT device memory-access checking.
timeout 240 .venv/bin/python -m torch.distributed.run --standalone --nproc_per_node=2 \
  --no-python /usr/local/cuda/bin/compute-sanitizer --tool memcheck \
  --report-api-errors no --kernel-name kns=exchange_kernel --error-exitcode 99 \
  .venv/bin/python scripts/fused_exchange_stress.py --rows 9 129 --iterations 5 \
  --output results/fused_memcheck_scoped.json
