"""Independent publication oracle, ties, poisoned tails and graph refresh."""
import argparse
from common import save


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--ant-source', required=True)
    p.add_argument('--output', default='results/indexer_v2_edges.json')
    args = p.parse_args()
    import torch
    from bridge_v2 import PublishedCandidates
    from ant_kernel_runtime import enable
    plan_fn, topk = enable(args.ant_source)
    torch.cuda.set_device(0)
    torch.manual_seed(1234)
    tests = []
    for rows in (1, 8, 32):
        for width in (1, 7, 63, 2048):
            for unique in (False, True):
                ws = PublishedCandidates(rows, width, 'cuda')
                host_blocks = torch.stack([torch.randperm(65536)[:width] for _ in range(rows)]).int()
                if not unique and width > 2:
                    host_blocks[:, 1] = host_blocks[:, 0]
                    host_blocks[:, 2] = -1
                lengths = torch.tensor([0, 1, 7, 8, 9, 511, 517, 262143] * ((rows+7)//8), dtype=torch.int32)[:rows]
                blocks, lens = host_blocks.cuda(), lengths.cuda()
                def publish(): ws.publish(blocks, lens, source_unique=unique, backend='cub')
                publish()
                g = torch.cuda.CUDAGraph()
                with torch.cuda.graph(g): publish()
                for step in range(3):
                    if step:
                        lengths = (lengths + 131071).clamp(max=524288)
                        lens.copy_(lengths)
                        host_blocks = host_blocks.roll(1, dims=1)
                        blocks.copy_(host_blocks)
                    g.replay()
                    got, counts = ws.blocks.cpu().tolist(), ws.counts.cpu().tolist()
                    for r, n in enumerate(lengths.tolist()):
                        valid = sorted({b for b in host_blocks[r].tolist() if 0 <= b < (n+7)//8})
                        assert got[r] == valid + [2147483647] * (width-len(valid))
                        assert counts[r] == sum(min(8,n-b*8) for b in valid)
                    tests.append(dict(kind='publication_graph_refresh', rows=rows,
                                      width=width, unique=unique, step=step))
    # Top-k has a deterministic tie rule on the <=16K register path. Poison
    # padding with NaNs: correctness requires respecting counts, not full width.
    rows, width = 8, 16384
    counts = torch.tensor([0,1,511,512,513,8191,16383,16384],device='cuda',dtype=torch.int32)
    mapping = torch.arange(2048,device='cuda',dtype=torch.int32)[None,:].expand(rows,-1).contiguous()*2
    scores = torch.empty((rows,width),device='cuda',dtype=torch.float32)
    out = torch.empty((rows,512),device='cuda',dtype=torch.int32)
    plan = plan_fn(counts)
    for mode in ('equal','many_ties','signed'):
        for row, n in enumerate(counts.cpu().tolist()):
            scores[row].fill_(float('nan'))
            if mode == 'equal': scores[row,:n].zero_()
            elif mode == 'many_ties': scores[row,:n] = torch.arange(n,device='cuda') % 4
            else: scores[row,:n] = (torch.arange(n,device='cuda') % 23 - 11).float()
        topk(scores,counts,mapping,out,8,plan,det_ties=True)
        reference = []
        for row, n in enumerate(counts.cpu().tolist()):
            best = torch.argsort(scores[row,:n],descending=True,stable=True)[:512]
            expected = ((best//8)*16 + best%8).cpu().tolist()
            reference.append(set(expected))
        for repeat in range(3):
            topk(scores,counts,mapping,out,8,plan,det_ties=True)
            for row, values in enumerate(out.cpu().tolist()):
                selected = [v for v in values if v>=0]
                assert len(selected) == len(set(selected))
                assert set(selected) == reference[row]
                assert all(v>=0 or v == -1 for v in values)
        tests.append(dict(kind='topk_ties_poisoned_tail', mode=mode, rows=rows))
    save(args.output, dict(status='passed', tests=tests))
    print(f'Passed {len(tests)} edge test groups', flush=True)


if __name__ == '__main__':
    main()
