"""Candidate state published once and reused by same-mapping consumers.

One sort + scan compaction preserves the original robust duplicate/invalid
handling. No host reads; allocation and metadata lifetime belong to the caller.
The state is reusable ONLY for identical query order, lengths, candidate set,
and compression ratio. Rebuild after any change, including a new decode step.
"""
import triton
import triton.language as tl
from functools import lru_cache
from pathlib import Path
from bridge import CandidateWorkspace


@triton.jit
def _canonical_unique(BLOCKS, LENS, SORTED, COUNTS, K: tl.constexpr,
                      BLOCK: tl.constexpr, TILE: tl.constexpr):
    # Contract: nonnegative candidate IDs are unique (native source top-k).
    # Invalid IDs may repeat. Matches Ant's single source-side sort/count.
    row = tl.program_id(0)
    i = tl.arange(0, TILE)
    length = tl.maximum(tl.load(LENS + row), 0)
    b = tl.load(BLOCKS + row * K + i, i < K, -1)
    sentinel = 2147483647
    b = tl.sort(tl.where((i < K) & (b >= 0) & (b < tl.cdiv(length, BLOCK)), b, sentinel))
    tl.store(SORTED + row * K + i, b, i < K)
    n = tl.where(b != sentinel, tl.minimum(tl.maximum(length - b * BLOCK, 0), BLOCK), 0)
    tl.store(COUNTS + row, tl.sum(n, 0))


@triton.jit
def _canonical_scan(BLOCKS, LENS, SORTED, COUNTS, K: tl.constexpr,
                    BLOCK: tl.constexpr, TILE: tl.constexpr):
    row = tl.program_id(0)
    i = tl.arange(0, TILE)
    length = tl.maximum(tl.load(LENS + row), 0)
    b = tl.load(BLOCKS + row * K + i, i < K, -1)
    sentinel = 2147483647
    b = tl.sort(tl.where((i < K) & (b >= 0) & (b < tl.cdiv(length, BLOCK)), b, sentinel))
    previous = tl.gather(b, tl.maximum(i - 1, 0), 0)
    unique = (b != sentinel) & ((i == 0) | (b != previous))
    rank = tl.cumsum(unique.to(tl.int32)) - 1
    num_unique = tl.sum(unique.to(tl.int32), 0)
    # Prefix and suffix destinations are disjoint, including an empty row.
    tl.store(SORTED + row * K + i, sentinel, (i < K) & (i >= num_unique))
    tl.store(SORTED + row * K + rank, b, unique)
    n = tl.where(unique, tl.minimum(tl.maximum(length - b * BLOCK, 0), BLOCK), 0)
    tl.store(COUNTS + row, tl.sum(n, 0))


class PublishedCandidates(CandidateWorkspace):
    def publish(self, blocks, lengths, *, source_unique=False, backend='triton'):
        if backend == 'cub' and source_unique and self.candidates == 2048 and self.block == 8:
            _cub_module().run(blocks, lengths, self.blocks, self.counts)
            return
        assert backend in ('triton', 'cub')
        kernel = _canonical_unique if source_unique else _canonical_scan
        kernel[(blocks.shape[0],)](
            blocks, lengths, self.blocks, self.counts, self.candidates,
            self.block, triton.next_power_of_2(self.candidates), num_warps=8)


@lru_cache(maxsize=1)
def _cub_module():
    # Called only after the explicit kernel-only Ant runtime initialization.
    from sglang.kernels.jit.utils import load_jit
    return load_jit('dsv41_local_candidate_publish',
        cuda_files=[str(Path(__file__).with_name('candidate_publish.cuh'))],
        cuda_wrappers=[('run', 'CandidatePublish::run')])

