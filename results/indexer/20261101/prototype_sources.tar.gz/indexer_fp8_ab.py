"""Actual H20 FP8 baseline vs Ant-derived candidate FP8 WGMMA. No model weights.

Only --run-gpu invokes CUDA. --plan is stdlib-only and does not import torch.
"""
import argparse
import itertools
import json
import math
from pathlib import Path

from common import ROOT, check_sources, check_vllm, device_info, measure, save


def cases(args):
    for rows, context, ratio, verify in itertools.product(
            args.rows, args.context, args.ratios, args.verify):
        if rows % verify:
            continue
        length = context // ratio
        capacity = min(2048, math.ceil(length / 8)) * 8
        yield dict(rows=rows, context_tokens=context, compress_ratio=ratio,
                   compressed_length=length, rows_per_request=verify,
                   candidate_blocks=min(2048, math.ceil(length / 8)),
                   candidate_capacity=capacity, index_heads=32, index_dim=128,
                   topk=512, block_size=8, page_size=64,
                   ant_policy_compact=length >= 16 * capacity)


class VllmSelector:
    """Exact auto top-k C ops for SM90 with fixed topk=512, aligned FP32 logits.

    Mirrors pinned indexer_topk.py; owns the same 1 MiB workspace rather than
    constructing a model/WorkspaceManager. No torch.topk performance baseline.
    """
    def __init__(self, device, rows):
        import torch
        import vllm._C_stable_libtorch  # noqa: F401: v0.32 native CUDA ops
        self.workspace = torch.empty(1024 * 1024, device=device, dtype=torch.uint8)
        self.backend = 'cooperative' if rows <= 64 else 'persistent'

    def __call__(self, scores, lengths, output, max_len):
        import torch
        op = getattr(torch.ops._C, self.backend + '_topk')
        op(scores, lengths, output, self.workspace, 512, max_len)


def make_inputs(case, *, stress=False):
    import torch
    r, length, verify = case['rows'], case['compressed_length'], case['rows_per_request']
    requests, page = r // verify, case['page_size']
    pages = math.ceil(length / page)
    generator = torch.Generator(device='cuda').manual_seed(20261101)
    # Finite signed E4M3 encodings; same bytes for both paths. Generate in chunks
    # to avoid an unnecessary full-size FP32 staging tensor for long contexts.
    raw = torch.empty((requests * pages, page * 132), device='cuda', dtype=torch.uint8)
    for start in range(0, raw.shape[0], 1024):
        stop = min(start + 1024, raw.shape[0])
        payload = torch.randn((stop-start, page*128), generator=generator, device='cuda').to(torch.float8_e4m3fn)
        raw[start:stop, :page*128] = payload.view(torch.uint8)
        exps = torch.randint(-4 if stress else -1, 5 if stress else 2, (stop-start, page), generator=generator, device='cuda')
        scale = torch.exp2(exps.float())
        raw[start:stop, page*128:] = scale.view(torch.uint8)
    cache = raw.view(requests * pages, page, 1, 132)
    block_table = torch.randperm(requests * pages, device='cuda', generator=generator).int().view(requests, pages)
    q = torch.randn((r,32,128), device='cuda', generator=generator).to(torch.float8_e4m3fn)
    # Query scales are already folded into weights in the upstream FP8 ABI.
    weights = torch.randn((r,32),device='cuda',generator=generator)/math.sqrt(128*32)
    req = torch.arange(requests,device='cuda').repeat_interleave(verify).int()
    offsets = torch.arange(verify,device='cuda').repeat(requests)
    lens = (length-verify+1+offsets).clamp_min(0).int()
    blocks = torch.stack([torch.randperm(pages*page//8,device='cuda',generator=generator)[:case['candidate_blocks']] for _ in range(r)]).int()
    if stress:
        lens[0]=0
        if r>1:
            lens[1]=min(length,517)
        blocks[:,1]=blocks[:,0]
        blocks[:,2]=-1
    blocks[:,-1]=(lens-1)//8
    return q, None, weights, cache, block_table, req, lens, blocks


def run_case(case, args):
    import torch
    from vllm.utils.deep_gemm import fp8_fp4_paged_mqa_logits, get_paged_mqa_logits_metadata
    from vllm.model_executor.kernels.attention.dsa.candidate_blocks import apply_candidate_mask
    from ant_candidate_fp8_port import fp4_index_logits_candidates_wgmma
    from bridge import CandidateWorkspace

    q, qs, weights, cache, table, req, lens, blocks = make_inputs(case, stress=args.stress)
    r, length, page = case['rows'], case['compressed_length'], case['page_size']
    verify = case['rows_per_request']
    ws = CandidateWorkspace(r, blocks.shape[1], q.device, q_dtype=q.dtype)
    ws.q = q  # FP8 Q is already in the native layout, no conversion/copy.
    selector = VllmSelector(q.device, r)
    output = torch.empty((r, 512), device='cuda', dtype=torch.int32)
    native_n = verify if verify in (1, 2, 4) else 1
    baseline_table = table if native_n == verify else table[req.long()].contiguous()
    baseline_lens = lens.view(-1, native_n)
    baseline_q = q.view(-1, native_n, 32, 128)
    baseline_scales = None
    sms = torch.cuda.get_device_properties(q.device).multi_processor_count
    baseline_metadata = get_paged_mqa_logits_metadata(baseline_lens, page, sms)

    def baseline_scores(refresh=True):
        md = get_paged_mqa_logits_metadata(baseline_lens, page, sms) if refresh else baseline_metadata
        scores = fp8_fp4_paged_mqa_logits((baseline_q, baseline_scales), cache,
                   weights, baseline_lens, baseline_table, md, length, clean_logits=False)
        apply_candidate_mask(scores, None, lens, blocks, 8, 1)
        return scores

    def baseline():
        # Real sparse_attn_indexer consumes scheduler metadata built by the
        # attention metadata builder; do not charge its reconstruction per layer.
        scores = baseline_scores(False)
        selector(scores, baseline_lens, output, length)
        return output

    def baseline_metadata_included():
        scores = baseline_scores(True)
        selector(scores, baseline_lens, output, length)
        return output

    def port_scores(fp32=True, prepare=True):
        if prepare:
            ws.prepare_candidates(blocks, lens)
        w = weights if fp32 else weights.to(torch.bfloat16)
        fp4_index_logits_candidates_wgmma(ws.q, w, table, req, ws.blocks,
            ws.counts, cache, page, ws.scores,
            cache_page_size=page, candidate_block_size=8, fp32_scores=fp32)
        return ws.scores

    def optimized(fp32=True):
        port_scores(fp32)
        selector(ws.scores, ws.counts.view(r, 1), ws.selected, ws.scores.shape[1])
        return ws.map_output()

    # All correctness evaluation occurs before timings, but only on an explicit
    # GPU run. Report native BF16 errors separately; never silently bless them.
    original = baseline().clone()
    full_scores = baseline_scores().clone()
    validation = {}
    for name, fp32 in [('ant_vllm_fp32', True)]:
        selected = optimized(fp32).clone()
        positions = (ws.blocks.long()[..., None] * 8 + torch.arange(8, device='cuda')).flatten(1)
        visible = torch.arange(positions.shape[1], device='cuda')[None, :] < ws.counts[:, None]
        expected = full_scores.gather(1, positions.clamp(0, length - 1))
        difference = (ws.scores[visible] - expected[visible]).float()
        norm = expected[visible].float().norm().clamp_min(1e-20)
        nrmse = (difference.norm() / norm).item()
        max_abs = difference.abs().max().item() if difference.numel() else 0.0
        a, b = original.cpu().tolist(), selected.cpu().tolist()
        old_finite = torch.isfinite(full_scores.gather(1, original.long().clamp(0, length - 1))).cpu().tolist()
        host_lens = lens.cpu().tolist()
        allowed_rows = [set(positions[i][visible[i]].cpu().tolist()) for i in range(r)]
        recall = []
        for row, (old, new) in enumerate(zip(a, b)):
            oldset = {x for x, finite in zip(old, old_finite[row]) if x >= 0 and finite}
            newlist = [x for x in new if x >= 0]
            assert len(newlist) == len(set(newlist)), 'duplicate selected positions'
            assert all(x < host_lens[row] for x in newlist), 'causal violation'
            allowed = allowed_rows[row]
            assert set(newlist) <= allowed, 'outside candidate blocks'
            assert len(newlist) == min(512, len(allowed)), 'underfill/overflow'
            recall.append(len(oldset & set(newlist)) / max(1, len(oldset)) if oldset else float(not newlist))
        validation[name] = dict(score_nrmse=nrmse, score_max_abs=max_abs,
            min_topk_set_recall=min(recall), mean_topk_set_recall=sum(recall)/len(recall),
            numerical_gate_pass=nrmse <= args.max_nrmse and min(recall) >= args.min_recall,
            native_rounding_comparator=not fp32)

    # Independent dequantization and FP32 matmul check for a bounded sample,
    # including negative weights; baseline agreement alone is not an oracle.
    port_scores(True)
    references = []
    baseline_references = []
    for row in range(min(2, r)):
        count = int(ws.counts[row])
        if not count:
            continue
        pos = positions[row, :count]
        physical = table[req[row].long(), pos // page].long()
        raw = cache.view(cache.shape[0], page * 132)
        payload = raw[physical[:, None], (pos % page)[:, None] * 128 + torch.arange(128, device='cuda')]
        scales = raw[physical[:, None], page * 128 + (pos % page)[:, None] * 4 + torch.arange(4, device='cuda')]
        kvals = payload.contiguous().view(torch.float8_e4m3fn).float() * scales.contiguous().view(torch.float32)
        scores = ((ws.q[row].float() @ kvals.T).clamp_min(0) * weights[row, :, None]).sum(0)
        got = ws.scores[row, :count]
        rel = ((got - scores).norm()/scores.norm().clamp_min(1e-20)).item()
        references.append(rel)
        baseline_got = full_scores[row, pos]
        baseline_references.append(((baseline_got - scores).norm()/scores.norm().clamp_min(1e-20)).item())
    validation['fp32_reference_max_nrmse'] = max(references, default=0.0)
    validation['baseline_fp32_reference_max_nrmse'] = max(baseline_references, default=0.0)
    # The original FP8 tensor-core path also differs from an FP32 reference.
    # Require close agreement with it AND no material extra reference error.
    reference_gate = all(new <= old + args.max_nrmse for new, old in zip(references, baseline_references))
    eligible = validation['ant_vllm_fp32']['numerical_gate_pass'] and reference_gate
    result = dict(case=case, cache_dtype='fp8_e4m3fn', correctness=validation, eligible_for_speedup_claim=eligible,
                  topk_backend=selector.backend, timings={}, force_compact=True,
                  ant_policy_would_enable=case['ant_policy_compact'])
    # Native-rounding comparator is timed but cannot become the recommended
    # implementation merely because its narrower arithmetic is faster.
    variants = [('vllm_original', baseline), ('ant_vllm_fp32', optimized),
                ('vllm_total_with_metadata_rebuild_diagnostic', baseline_metadata_included),
                ('vllm_score_mask_only_metadata_reused', lambda: baseline_scores(False)),
                ('ant_score_only_inputs_prepared', lambda: port_scores(True, False))]
    if args.reverse_order:
        variants.reverse()
    for mode in args.modes:
        result['timings'][mode] = {}
        for name, fn in variants:
            result['timings'][mode][name] = measure(fn, repeats=args.repeats,
                inner=args.inner, graph=mode == 'graph')
        t = result['timings'][mode]
        result['timings'][mode]['measured_ratio_baseline_over_port'] = (
            t['vllm_original']['p50_us'] / t['ant_vllm_fp32']['p50_us'])
    if args.ant_source:
        from sglang.kernels.ops.attention.dsv4.topk import plan_topk_v2, topk_transform_paged_v2

        def ant_topk_pipeline():
            ws.prepare_candidates(blocks, lens)
            # Ant explicitly requires the plan launch before scoring, not
            # immediately before top-k. Include fresh plans in this benchmark.
            plan = plan_topk_v2(ws.counts)
            port_scores(True, False)
            topk_transform_paged_v2(ws.scores, ws.counts, None, ws.selected, 1,
                                   plan, det_ties=True)
            return ws.map_output()

        native_out = ant_topk_pipeline().clone()
        control_out = optimized().clone()
        def as_sets(t):
            return [set(x for x in row if x >= 0) for row in t.cpu().tolist()]
        native_sets, control_sets = as_sets(native_out), as_sets(control_out)
        assert all(len(s) == min(512, int(ws.counts[i])) for i, s in enumerate(native_sets))
        assert all(s <= set(positions[i][visible[i]].cpu().tolist()) for i, s in enumerate(native_sets))
        result['correctness']['ant_topk_v2'] = dict(
            min_set_recall_vs_vllm_topk=min(
                len(a & b) / len(b) if b else float(not a)
                for a, b in zip(native_sets, control_sets)),
            note='Top-k ties can differ; original Ant documents cluster threshold-bin tie limits.')
        for mode in args.modes:
            result['timings'][mode]['ant_fp32_with_ant_topk_v2'] = measure(
                ant_topk_pipeline, repeats=args.repeats, inner=args.inner, graph=mode == 'graph')
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__)
    action = p.add_mutually_exclusive_group(required=True)
    action.add_argument('--plan', action='store_true')
    action.add_argument('--run-gpu', action='store_true')
    p.add_argument('--rows', type=int, nargs='+', default=[1, 8, 32, 128])
    p.add_argument('--context', type=int, nargs='+', default=[65536, 131072, 262144])
    p.add_argument('--ratios', type=int, nargs='+', choices=[1, 2], default=[1, 2])
    p.add_argument('--verify', type=int, nargs='+', default=[1, 4])
    p.add_argument('--modes', nargs='+', choices=['eager', 'graph'], default=['eager', 'graph'])
    p.add_argument('--stress', action='store_true')
    p.add_argument('--reverse-order', action='store_true', help='Counterbalance measurement order')
    p.add_argument('--ant-source', help='Extracted ant-runtime.tar.gz root; also test actual Ant top-k v2')
    p.add_argument('--repeats', type=int, default=30)
    p.add_argument('--inner', type=int, default=10)
    p.add_argument('--max-nrmse', type=float, default=1e-4)
    p.add_argument('--min-recall', type=float, default=.99)
    p.add_argument('--output', default='results/indexer_fp8.json')
    args = p.parse_args()
    assert min(args.rows + args.context + args.verify) > 0
    assert min(args.context) // max(args.ratios) >= 512, 'K=512 needs capacity >=512'
    assert all((context // ratio) % 4 == 0 for context in args.context for ratio in args.ratios), 'This benchmark fixes aligned logits widths'
    assert args.repeats > 0 and args.inner > 0
    check_sources()
    if args.plan:
        print(json.dumps(list(cases(args)), indent=2))
        return
    import torch
    torch.cuda.set_device(0)
    torch.backends.cuda.matmul.allow_tf32 = False
    if args.ant_source:
        from ant_runtime import enable
        enable(args.ant_source)
    result = dict(status='running', device=device_info(), baseline=check_vllm(),
                  args=vars(args), provenance=check_sources(), cases=[])
    try:
        for case in cases(args):
            entry = run_case(case, args)
            result['cases'].append(entry)
            save(args.output, result)
            print(json.dumps({'case': case, 'correctness': entry['correctness']}), flush=True)
        result['status'] = 'completed'
    except BaseException as exc:
        result.update(status='failed', error=repr(exc))
        raise
    finally:
        save(args.output, result)


if __name__ == '__main__':
    main()
