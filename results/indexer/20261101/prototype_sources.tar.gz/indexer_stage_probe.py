"""Profile the old compact path; optional unchanged Ant top-k v2 comparison."""
import argparse
import json
from common import measure, save


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--rows', type=int, nargs='+', default=[1, 8, 32])
    p.add_argument('--ant-source')
    p.add_argument('--output', default='results/stage_probe.json')
    args = p.parse_args()
    import torch
    from indexer_fp8_ab import make_inputs, VllmSelector
    from bridge import CandidateWorkspace
    from bridge_v2 import PublishedCandidates, _canonical_unique
    from ant_candidate_fp8_port import fp4_index_logits_candidates_wgmma as score
    native = None
    if args.ant_source:
        from ant_kernel_runtime import enable
        native = enable(args.ant_source)
    result = []
    for rows in args.rows:
        case = dict(rows=rows, compressed_length=262144, rows_per_request=1,
                    page_size=64, candidate_blocks=2048)
        q, _, weights, cache, table, req, lens, blocks = make_inputs(case)
        ws = CandidateWorkspace(rows, 2048, q.device, q_dtype=q.dtype)
        ws.q = q
        fast = PublishedCandidates(rows, 2048, q.device, q_dtype=q.dtype)
        fast.q = q
        selector = VllmSelector(q.device, rows)
        def prep(): ws.prepare_candidates(blocks, lens)
        def scores(): score(q, weights, table, req, ws.blocks, ws.counts,
                           cache, 64, ws.scores, cache_page_size=64,
                           candidate_block_size=8, fp32_scores=True)
        def topk(): selector(ws.scores, ws.counts[:, None], ws.selected, 16384)
        prep(); scores(); topk(); ws.map_output()
        fast.publish(blocks, lens)
        assert torch.equal(fast.blocks, ws.blocks)
        assert torch.equal(fast.counts, ws.counts)
        ops = dict(prepare_two_sorts=prep, score=scores, vllm_topk=topk,
                   map=ws.map_output, prepare_sort_scan=lambda: fast.publish(blocks, lens))
        # Separate cost diagnostic only; benchmark input may contain duplicate
        # newest blocks, so this operation is not used to generate outputs here.
        ops['prepare_unique_contract_cost_only'] = lambda: fast.publish(blocks, lens, source_unique=True)
        for warps in (4, 16, 32):
            def tuned(warps=warps):
                _canonical_unique[(rows,)](blocks, lens, fast.blocks, fast.counts,
                                          2048, 8, 2048, num_warps=warps)
            ops[f'prepare_unique_warps{warps}_cost_only'] = tuned
        if native:
            ops['prepare_cub_unique_contract_cost_only'] = lambda: fast.publish(blocks, lens, source_unique=True, backend='cub')
            plan_fn, native_topk = native
            plan = plan_fn(ws.counts)
            def ant_topk():
                native_topk(ws.scores, ws.counts, None, ws.selected, 1, plan, det_ties=True)
            def ant_fused_map():
                native_topk(ws.scores, ws.counts, ws.blocks, ws.output, 8, plan, det_ties=True)
            original = ws.output.clone()
            ant_topk(); ws.map_output()
            assert torch.equal(original.sort(1).values, ws.output.sort(1).values)
            ant_fused_map()
            assert torch.equal(original.sort(1).values, ws.output.sort(1).values)
            ops.update(ant_plan=lambda: plan_fn(ws.counts, out=plan),
                       ant_topk=ant_topk, ant_topk_fused_map=ant_fused_map)
        entry = dict(rows=rows, timings={})
        for name, fn in ops.items():
            entry['timings'][name] = measure(fn, graph=True)
        result.append(entry)
        save(args.output, result)
        print(json.dumps(dict(rows=rows, timings={k: v['p50_us'] for k,v in entry['timings'].items()})), flush=True)


if __name__ == '__main__':
    main()
