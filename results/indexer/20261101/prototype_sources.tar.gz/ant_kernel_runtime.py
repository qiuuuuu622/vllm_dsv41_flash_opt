"""Isolated kernel-only import of the pinned Ant snapshot.

Skip serving-package initializers, not kernel code. Hardware predicates are
AST-extracted verbatim from Ant; all JIT, occupancy, top-k Python/CUDA sources
are loaded unchanged. This avoids installing a different Torch for SGLang.
Never use in a serving process, where replacing package namespaces is unsafe.
"""
import ast
import functools
import hashlib
import importlib.util
import json
import logging
from pathlib import Path
import sys
import types
from typing import List, Tuple, Optional


def enable(root):
    import torch
    root = Path(root).resolve()
    here = Path(__file__).resolve().parent
    lock = json.loads((here / 'ant-runtime-files.json').read_text())
    for relative, sha in lock.items():
        path = root / relative
        assert hashlib.sha256(path.read_bytes()).hexdigest() == sha, path
    assert 'sglang' not in sys.modules, 'Use a fresh kernel benchmark process'
    for name in ('sglang', 'sglang.srt', 'sglang.srt.utils', 'sglang.kernels',
                 'sglang.kernels.jit', 'sglang.kernels.ops',
                 'sglang.kernels.ops.attention', 'sglang.kernels.ops.attention.dsv4'):
        directory = root / 'python' / name.replace('.', '/')
        module = types.ModuleType(name)
        module.__path__ = [str(directory)]
        module.__file__ = str(directory / '__init__.py')
        module.__spec__ = importlib.util.spec_from_file_location(
            name, module.__file__, submodule_search_locations=module.__path__)
        sys.modules[name] = module
        if '.' in name:
            parent, child = name.rsplit('.', 1)
            setattr(sys.modules[parent], child, module)
    source = root / 'python/sglang/srt/utils/common.py'
    tree = ast.parse(source.read_text())
    names = ('is_cuda', 'is_xpu', 'is_musa', 'get_device_sm',
             '_get_device_sm_via_nvml', '_check_cuda_device_version')
    functions = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name in names]
    functions += [n for n in tree.body if isinstance(n, ast.Assign)
                  and any(isinstance(t, ast.Name) and t.id == 'is_sm90_supported' for t in n.targets)]
    assert len(functions) == len(names) + 1
    module = types.ModuleType('sglang.srt.utils.common')
    module.__dict__.update(torch=torch, lru_cache=functools.lru_cache,
                           partial=functools.partial, List=List, Tuple=Tuple, Optional=Optional,
                           logger=logging.getLogger(__name__))
    exec(compile(ast.Module(body=functions, type_ignores=[]), str(source), 'exec'), module.__dict__)
    sys.modules[module.__name__] = module
    sys.modules['sglang.srt.utils'].is_xpu = module.is_xpu
    from sglang.kernels.ops.attention.dsv4.topk import plan_topk_v2, topk_transform_paged_v2
    return plan_topk_v2, topk_transform_paged_v2
